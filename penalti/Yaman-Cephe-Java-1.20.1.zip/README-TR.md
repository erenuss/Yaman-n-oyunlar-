# Yaman Cephe — modsuz veri paketi
Minecraft Java 1.20.1 için hazırlanan, 1. Dünya Savaşı siperlerinden esinlenen bir bayrak ele geçirme arenası. TaCZ ve ActualGuns dahil değildir. Silah modu yoktur; Minecraft'ın yayı kullanılır. Tarihsel savaş simülasyonu değildir.

## Durum
Dosyalar hazırlandı; gerçek Minecraft sunucusunda yükleme ve iki oyunculu oynanış henüz doğrulanmadı. Sunucu adresi yoktur. Bu ZIP tek başına çevrimiçi sunucu değildir.

## Kurulum
1. Yeni ve bu oyun için ayrılmış bir Minecraft Java 1.20.1 sunucusu oluştur.
2. ZIP'i açmadan dünyanın datapacks klasörüne yükle.
3. Sunucuyu tamamen yeniden başlat. Yeni boyut için yalnızca /reload yeterli değildir.
4. Konsolda function yaman:kurulum çalıştır (oyun içinden başında / kullan).
5. Oyuncular /trigger cephe_katil komutuyla katılır. Her iki takımda oyuncu olunca tur otomatik başlar.
6. Çıkmak için /trigger cephe_cik kullan.

Harita yalnızca yaman:cephe adlı yeni boyutta oluşturulur. Kurulum tekrar çağrıldığında mevcut haritayı silmez. Katılım oyuncunun oyun modunu, doğma noktasını ve zırhını değiştirir; ekipman verir. Kurulum sunucuda keepInventory ve doImmediateRespawn ayarlarını açar; yaratık doğmasını, yaratıkların bloklara zarar vermesini ve zaman/hava döngüsünü kapatır. Bu yüzden mevcut bir hayatta kalma dünyasına değil, ayrı bir arena sunucusuna kurulmalıdır.

## Oyun
- Mavi ve Altın takımlarına dengeli otomatik katılım.
- Üç bayrak: z=-28, 0, 28.
- Bir bayrağın altı blok yakınında 10 saniye bekleyerek ele geçirme.
- Rakip takım da bölgede ise ele geçirme ilerlemesi durur.
- Sahip olunan bayrak başına saniyede 1 puan; 300 puan veya 10 dakika.
- Siperler, tahta geçitler, harabeler, iki korunaklı üs.
- Dost ateşi kapalı; ölümden sonra hızlı dönüş; üste iyileşme.
- Bir takımda oyuncu kalmazsa tur iptal edilir, yeni eşleşme beklenir.
- Yönetici function yaman:iptal ile turu iptal edebilir.

## Barındırma
GitHub Pages yalnızca katılma bilgilerini gösteren web sayfasını barındırır. Gerçek oyun Aternos gibi ayrı bir Minecraft sunucusunda çalışmalıdır. Her oyuncu aynı Minecraft sürümünü kullanmalıdır. Çevrimiçi doğrulama açık tutulmalıdır; oyuncu adı tek başına yönetici yetkisi vermez.

## Lisans
Bu paketteki özgün komutlar ve harita üretimi CC0-1.0 ile kullanılabilir. Minecraft, Mojang/Microsoft'un ürünüdür; bu bağımsız paket onlarla bağlantılı değildir.
