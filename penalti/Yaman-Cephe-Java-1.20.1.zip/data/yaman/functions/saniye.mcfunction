function yaman:say
execute if score #aktif ym matches 0 if score #mavi ym matches 1.. if score #altin ym matches 1.. run scoreboard players remove #bekle ym 1
execute if score #aktif ym matches 0 if score #bekle ym matches ..0 run function yaman:baslat
execute if score #aktif ym matches 0 run title @a[tag=ym_oyuncu] actionbar {"text":"İki takımda da oyuncu olduğunda maç kısa süre içinde başlar.","color":"yellow"}
execute if score #aktif ym matches 1 unless score #mavi ym matches 1.. run function yaman:iptal
execute if score #aktif ym matches 1 unless score #altin ym matches 1.. run function yaman:iptal
execute if score #aktif ym matches 1 run function yaman:mac
execute positioned -51 65 0 run effect give @a[tag=ym_oyuncu,team=ym_mavi,distance=..6] minecraft:regeneration 2 1 true
execute positioned 51 65 0 run effect give @a[tag=ym_oyuncu,team=ym_altin,distance=..6] minecraft:regeneration 2 1 true
