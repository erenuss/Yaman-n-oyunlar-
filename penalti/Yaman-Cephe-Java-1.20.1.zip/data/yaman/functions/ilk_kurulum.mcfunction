scoreboard players set #hazir ym 2
execute in yaman:cephe run forceload add -64 -48 64 48
schedule function yaman:yuklemeyi_bekle 3s replace
tellraw @a {"text":"Cephe, ayrı bir boyutta kuruluyor…","color":"yellow"}
