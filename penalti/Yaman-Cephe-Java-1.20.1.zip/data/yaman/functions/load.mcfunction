scoreboard objectives add ym dummy
scoreboard objectives add Cephe dummy {"text":"YAMAN • CEPHE","color":"gold"}
scoreboard objectives add cephe_katil trigger
scoreboard objectives add cephe_cik trigger
scoreboard objectives add ym_olum deathCount
team add ym_mavi {"text":"Mavi Birlik","color":"aqua"}
team add ym_altin {"text":"Altın Birlik","color":"gold"}
team modify ym_mavi color aqua
team modify ym_altin color gold
team modify ym_mavi friendlyFire false
team modify ym_altin friendlyFire false
execute unless score #hazir ym matches 0.. run scoreboard players set #hazir ym 0
execute unless score #aktif ym matches 0.. run scoreboard players set #aktif ym 0
scoreboard players set #tick ym 0
tellraw @a {"text":"Yaman Cephe yüklendi. Kurulum: /function yaman:kurulum | Katıl: /trigger cephe_katil","color":"gold"}
