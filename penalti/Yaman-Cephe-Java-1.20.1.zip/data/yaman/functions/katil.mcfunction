function yaman:say
execute if score #mavi ym <= #altin ym run team join ym_mavi @s
execute if score #mavi ym > #altin ym run team join ym_altin @s
tag @s add ym_oyuncu
scoreboard players set @s cephe_cik 0
scoreboard players set @s ym_olum 0
function yaman:yeniden_dog
tellraw @s {"text":"Üç bayrağın çevresinde 10 saniye bekleyerek ele geçir. Rakip varsa ilerleme durur. Her bayrak saniyede 1 puan verir. 300 puan veya 10 dakikada en yüksek puan kazanır. Çıkış: /trigger cephe_cik","color":"yellow"}
