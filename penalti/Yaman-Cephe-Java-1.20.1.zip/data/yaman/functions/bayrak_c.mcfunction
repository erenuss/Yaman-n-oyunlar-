execute if entity @a[tag=ym_oyuncu,team=ym_mavi,gamemode=adventure,distance=..6] unless entity @a[tag=ym_oyuncu,team=ym_altin,gamemode=adventure,distance=..6] if score #pc ym matches ..9 run scoreboard players add #pc ym 1
execute if entity @a[tag=ym_oyuncu,team=ym_altin,gamemode=adventure,distance=..6] unless entity @a[tag=ym_oyuncu,team=ym_mavi,gamemode=adventure,distance=..6] if score #pc ym matches -9.. run scoreboard players remove #pc ym 1
execute if score #pc ym matches 0 run scoreboard players set #sc ym 0
execute if score #pc ym matches 10 run scoreboard players set #sc ym 1
execute if score #pc ym matches -10 run scoreboard players set #sc ym 2
execute if score #sc ym matches 1 run scoreboard players add Mavi Cephe 1
execute if score #sc ym matches 2 run scoreboard players add Altin Cephe 1
execute if score #sc ym matches 0 run fill 1 68 28 3 69 28 minecraft:white_wool
execute if score #sc ym matches 1 run fill 1 68 28 3 69 28 minecraft:light_blue_wool
execute if score #sc ym matches 2 run fill 1 68 28 3 69 28 minecraft:yellow_wool
