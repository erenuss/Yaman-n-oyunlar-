execute positioned 0 65 -28 run function yaman:bayrak_a
execute positioned 0 65 0 run function yaman:bayrak_b
execute positioned 0 65 28 run function yaman:bayrak_c
scoreboard players remove Sure Cephe 1
title @a[tag=ym_oyuncu] actionbar [{"text":"MAVİ ","color":"aqua"},{"score":{"name":"Mavi","objective":"Cephe"}},{"text":"  •  ALTIN ","color":"gold"},{"score":{"name":"Altin","objective":"Cephe"}},{"text":"  •  SÜRE ","color":"white"},{"score":{"name":"Sure","objective":"Cephe"}},{"text":" sn"}]
execute if score #aktif ym matches 1 if score Mavi Cephe matches 300.. run function yaman:bitir
execute if score #aktif ym matches 1 if score Altin Cephe matches 300.. run function yaman:bitir
execute if score #aktif ym matches 1 if score Sure Cephe matches ..0 run function yaman:bitir
