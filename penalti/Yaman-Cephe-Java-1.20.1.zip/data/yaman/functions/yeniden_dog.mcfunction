scoreboard players set @s ym_olum 0
gamemode adventure @s
execute if entity @s[team=ym_mavi] in yaman:cephe run tp @s -51 65 0 -90 0
execute if entity @s[team=ym_altin] in yaman:cephe run tp @s 51 65 0 90 0
execute if entity @s[team=ym_mavi] in yaman:cephe run spawnpoint @s -51 65 0
execute if entity @s[team=ym_altin] in yaman:cephe run spawnpoint @s 51 65 0
effect give @s minecraft:instant_health 1 5 true
effect give @s minecraft:saturation 1 5 true
effect give @s minecraft:resistance 5 4 true
function yaman:ekipman
