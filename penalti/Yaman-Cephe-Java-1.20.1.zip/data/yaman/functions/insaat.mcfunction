fill -64 65 -48 -49 82 48 minecraft:air
fill -48 65 -48 -33 82 48 minecraft:air
fill -32 65 -48 -17 82 48 minecraft:air
fill -16 65 -48 -1 82 48 minecraft:air
fill 0 65 -48 15 82 48 minecraft:air
fill 16 65 -48 31 82 48 minecraft:air
fill 32 65 -48 47 82 48 minecraft:air
fill 48 65 -48 63 82 48 minecraft:air
fill 64 65 -48 64 82 48 minecraft:air
fill -64 64 -48 64 64 48 minecraft:coarse_dirt
fill -64 65 -48 64 69 -48 minecraft:stone_bricks
fill -64 65 48 64 69 48 minecraft:stone_bricks
fill -64 65 -48 -64 69 48 minecraft:stone_bricks
fill 64 65 -48 64 69 48 minecraft:stone_bricks
fill -28 62 -40 -24 64 -28 minecraft:air
fill -29 62 -40 -29 64 -28 minecraft:spruce_planks
fill -23 62 -40 -23 64 -28 minecraft:spruce_planks
fill -28 61 -40 -24 61 -28 minecraft:spruce_planks
setblock -27 62 -35 minecraft:spruce_planks
setblock -28 63 -35 minecraft:spruce_planks
fill -32 62 -30 -28 64 -18 minecraft:air
fill -33 62 -30 -33 64 -18 minecraft:spruce_planks
fill -27 62 -30 -27 64 -18 minecraft:spruce_planks
fill -32 61 -30 -28 61 -18 minecraft:spruce_planks
setblock -31 62 -25 minecraft:spruce_planks
setblock -32 63 -25 minecraft:spruce_planks
fill -28 62 -20 -24 64 -8 minecraft:air
fill -29 62 -20 -29 64 -8 minecraft:spruce_planks
fill -23 62 -20 -23 64 -8 minecraft:spruce_planks
fill -28 61 -20 -24 61 -8 minecraft:spruce_planks
setblock -27 62 -15 minecraft:spruce_planks
setblock -28 63 -15 minecraft:spruce_planks
fill -32 62 -10 -28 64 2 minecraft:air
fill -33 62 -10 -33 64 2 minecraft:spruce_planks
fill -27 62 -10 -27 64 2 minecraft:spruce_planks
fill -32 61 -10 -28 61 2 minecraft:spruce_planks
setblock -31 62 -5 minecraft:spruce_planks
setblock -32 63 -5 minecraft:spruce_planks
fill -28 62 0 -24 64 12 minecraft:air
fill -29 62 0 -29 64 12 minecraft:spruce_planks
fill -23 62 0 -23 64 12 minecraft:spruce_planks
fill -28 61 0 -24 61 12 minecraft:spruce_planks
setblock -27 62 5 minecraft:spruce_planks
setblock -28 63 5 minecraft:spruce_planks
fill -32 62 10 -28 64 22 minecraft:air
fill -33 62 10 -33 64 22 minecraft:spruce_planks
fill -27 62 10 -27 64 22 minecraft:spruce_planks
fill -32 61 10 -28 61 22 minecraft:spruce_planks
setblock -31 62 15 minecraft:spruce_planks
setblock -32 63 15 minecraft:spruce_planks
fill -28 62 20 -24 64 32 minecraft:air
fill -29 62 20 -29 64 32 minecraft:spruce_planks
fill -23 62 20 -23 64 32 minecraft:spruce_planks
fill -28 61 20 -24 61 32 minecraft:spruce_planks
setblock -27 62 25 minecraft:spruce_planks
setblock -28 63 25 minecraft:spruce_planks
fill -32 62 30 -28 64 42 minecraft:air
fill -33 62 30 -33 64 42 minecraft:spruce_planks
fill -27 62 30 -27 64 42 minecraft:spruce_planks
fill -32 61 30 -28 61 42 minecraft:spruce_planks
setblock -31 62 35 minecraft:spruce_planks
setblock -32 63 35 minecraft:spruce_planks
fill -34 64 -31 -18 64 -29 minecraft:spruce_planks
fill -34 64 -1 -18 64 1 minecraft:spruce_planks
fill -34 64 29 -18 64 31 minecraft:spruce_planks
fill -58 65 -10 -44 69 10 minecraft:stone_bricks
fill -57 65 -9 -45 68 9 minecraft:air
fill -58 65 -2 -44 67 2 minecraft:air
fill -56 64 -7 -46 64 7 minecraft:light_blue_terracotta
setblock -51 68 0 minecraft:sea_lantern
fill -51 70 -8 -51 74 -8 minecraft:oak_fence
fill -50 72 -8 -48 74 -8 minecraft:light_blue_wool
fill 24 62 -40 28 64 -28 minecraft:air
fill 23 62 -40 23 64 -28 minecraft:spruce_planks
fill 29 62 -40 29 64 -28 minecraft:spruce_planks
fill 24 61 -40 28 61 -28 minecraft:spruce_planks
setblock 25 62 -35 minecraft:spruce_planks
setblock 24 63 -35 minecraft:spruce_planks
fill 28 62 -30 32 64 -18 minecraft:air
fill 27 62 -30 27 64 -18 minecraft:spruce_planks
fill 33 62 -30 33 64 -18 minecraft:spruce_planks
fill 28 61 -30 32 61 -18 minecraft:spruce_planks
setblock 29 62 -25 minecraft:spruce_planks
setblock 28 63 -25 minecraft:spruce_planks
fill 24 62 -20 28 64 -8 minecraft:air
fill 23 62 -20 23 64 -8 minecraft:spruce_planks
fill 29 62 -20 29 64 -8 minecraft:spruce_planks
fill 24 61 -20 28 61 -8 minecraft:spruce_planks
setblock 25 62 -15 minecraft:spruce_planks
setblock 24 63 -15 minecraft:spruce_planks
fill 28 62 -10 32 64 2 minecraft:air
fill 27 62 -10 27 64 2 minecraft:spruce_planks
fill 33 62 -10 33 64 2 minecraft:spruce_planks
fill 28 61 -10 32 61 2 minecraft:spruce_planks
setblock 29 62 -5 minecraft:spruce_planks
setblock 28 63 -5 minecraft:spruce_planks
fill 24 62 0 28 64 12 minecraft:air
fill 23 62 0 23 64 12 minecraft:spruce_planks
fill 29 62 0 29 64 12 minecraft:spruce_planks
fill 24 61 0 28 61 12 minecraft:spruce_planks
setblock 25 62 5 minecraft:spruce_planks
setblock 24 63 5 minecraft:spruce_planks
fill 28 62 10 32 64 22 minecraft:air
fill 27 62 10 27 64 22 minecraft:spruce_planks
fill 33 62 10 33 64 22 minecraft:spruce_planks
fill 28 61 10 32 61 22 minecraft:spruce_planks
setblock 29 62 15 minecraft:spruce_planks
setblock 28 63 15 minecraft:spruce_planks
fill 24 62 20 28 64 32 minecraft:air
fill 23 62 20 23 64 32 minecraft:spruce_planks
fill 29 62 20 29 64 32 minecraft:spruce_planks
fill 24 61 20 28 61 32 minecraft:spruce_planks
setblock 25 62 25 minecraft:spruce_planks
setblock 24 63 25 minecraft:spruce_planks
fill 28 62 30 32 64 42 minecraft:air
fill 27 62 30 27 64 42 minecraft:spruce_planks
fill 33 62 30 33 64 42 minecraft:spruce_planks
fill 28 61 30 32 61 42 minecraft:spruce_planks
setblock 29 62 35 minecraft:spruce_planks
setblock 28 63 35 minecraft:spruce_planks
fill 18 64 -31 34 64 -29 minecraft:spruce_planks
fill 18 64 -1 34 64 1 minecraft:spruce_planks
fill 18 64 29 34 64 31 minecraft:spruce_planks
fill 44 65 -10 58 69 10 minecraft:stone_bricks
fill 45 65 -9 57 68 9 minecraft:air
fill 44 65 -2 58 67 2 minecraft:air
fill 46 64 -7 56 64 7 minecraft:yellow_terracotta
setblock 51 68 0 minecraft:sea_lantern
fill 51 70 -8 51 74 -8 minecraft:oak_fence
fill 52 72 -8 54 74 -8 minecraft:yellow_wool
fill -15 64 -21 -9 65 -15 minecraft:air
fill -14 63 -20 -10 63 -16 minecraft:gravel
fill -16 65 -22 -11 67 -22 minecraft:mossy_stone_bricks
fill 9 64 15 15 65 21 minecraft:air
fill 10 63 16 14 63 20 minecraft:gravel
fill 8 65 14 13 67 14 minecraft:mossy_stone_bricks
fill -15 64 17 -9 65 23 minecraft:air
fill -14 63 18 -10 63 22 minecraft:gravel
fill -16 65 16 -11 67 16 minecraft:mossy_stone_bricks
fill 9 64 -23 15 65 -17 minecraft:air
fill 10 63 -22 14 63 -18 minecraft:gravel
fill 8 65 -24 13 67 -24 minecraft:mossy_stone_bricks
fill -8 64 36 -2 65 42 minecraft:air
fill -7 63 37 -3 63 41 minecraft:gravel
fill -9 65 35 -4 67 35 minecraft:mossy_stone_bricks
fill 2 64 -42 8 65 -36 minecraft:air
fill 3 63 -41 7 63 -37 minecraft:gravel
fill 1 65 -43 6 67 -43 minecraft:mossy_stone_bricks
fill -4 64 -32 4 64 -24 minecraft:smooth_stone
fill 0 65 -28 0 69 -28 minecraft:oak_fence
fill 1 68 -28 3 69 -28 minecraft:white_wool
setblock -3 64 -31 minecraft:sea_lantern
setblock 3 64 -25 minecraft:sea_lantern
fill -4 64 -4 4 64 4 minecraft:smooth_stone
fill 0 65 0 0 69 0 minecraft:oak_fence
fill 1 68 0 3 69 0 minecraft:white_wool
setblock -3 64 -3 minecraft:sea_lantern
setblock 3 64 3 minecraft:sea_lantern
fill -4 64 24 4 64 32 minecraft:smooth_stone
fill 0 65 28 0 69 28 minecraft:oak_fence
fill 1 68 28 3 69 28 minecraft:white_wool
setblock -3 64 25 minecraft:sea_lantern
setblock 3 64 31 minecraft:sea_lantern
