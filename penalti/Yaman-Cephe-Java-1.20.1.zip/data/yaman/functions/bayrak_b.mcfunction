execute if entity @a[tag=ym_oyuncu,team=ym_mavi,gamemode=adventure,distance=..6] unless entity @a[tag=ym_oyuncu,team=ym_altin,gamemode=adventure,distance=..6] if score #pb ym matches ..9 run scoreboard players add #pb ym 1
execute if entity @a[tag=ym_oyuncu,team=ym_altin,gamemode=adventure,distance=..6] unless entity @a[tag=ym_oyuncu,team=ym_mavi,gamemode=adventure,distance=..6] if score #pb ym matches -9.. run scoreboard players remove #pb ym 1
execute if score #pb ym matches 0 run scoreboard players set #sb ym 0
execute if score #pb ym matches 10 run scoreboard players set #sb ym 1
execute if score #pb ym matches -10 run scoreboard players set #sb ym 2
execute if score #sb ym matches 1 run scoreboard players add Mavi Cephe 1
execute if score #sb ym matches 2 run scoreboard players add Altin Cephe 1
execute if score #sb ym matches 0 run fill 1 68 0 3 69 0 minecraft:white_wool
execute if score #sb ym matches 1 run fill 1 68 0 3 69 0 minecraft:light_blue_wool
execute if score #sb ym matches 2 run fill 1 68 0 3 69 0 minecraft:yellow_wool
