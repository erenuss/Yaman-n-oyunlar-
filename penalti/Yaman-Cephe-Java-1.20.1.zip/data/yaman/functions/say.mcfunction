scoreboard players set #mavi ym 0
scoreboard players set #altin ym 0
execute as @a[tag=ym_oyuncu,team=ym_mavi] run scoreboard players add #mavi ym 1
execute as @a[tag=ym_oyuncu,team=ym_altin] run scoreboard players add #altin ym 1
