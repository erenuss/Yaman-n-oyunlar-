scoreboard players set #aktif ym 1
scoreboard players set Mavi Cephe 0
scoreboard players set Altin Cephe 0
scoreboard players set Sure Cephe 600
scoreboard objectives setdisplay sidebar Cephe
scoreboard players set #bekle ym 15
scoreboard players set #pa ym 0
scoreboard players set #sa ym 0
execute in yaman:cephe run fill 1 68 -28 3 69 -28 minecraft:white_wool
scoreboard players set #pb ym 0
scoreboard players set #sb ym 0
execute in yaman:cephe run fill 1 68 0 3 69 0 minecraft:white_wool
scoreboard players set #pc ym 0
scoreboard players set #sc ym 0
execute in yaman:cephe run fill 1 68 28 3 69 28 minecraft:white_wool
execute as @a[tag=ym_oyuncu] run function yaman:yeniden_dog
title @a[tag=ym_oyuncu] title {"text":"CEPHE BAŞLADI","color":"gold"}
title @a[tag=ym_oyuncu] subtitle {"text":"Bayrakları ele geçir • 300 puan","color":"white"}
