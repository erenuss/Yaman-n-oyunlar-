execute in yaman:cephe run function yaman:insaat
execute in yaman:cephe run forceload remove -64 -48 64 48
scoreboard players set #hazir ym 1
scoreboard players set #aktif ym 0
scoreboard players set #bekle ym 15
gamerule keepInventory true
gamerule doImmediateRespawn true
gamerule doMobSpawning false
gamerule mobGriefing false
gamerule doWeatherCycle false
gamerule doDaylightCycle false
execute in yaman:cephe run time set 6000
execute in yaman:cephe run weather clear
tellraw @a [{"text":"Yaman Cephe hazır! ","color":"green"},{"text":"[ARENAYA KATIL]","color":"aqua","bold":true,"clickEvent":{"action":"run_command","value":"/trigger cephe_katil"}},{"text":" Arena kendi ekipmanını verir; ayrı bir oyun sunucusu için tasarlanmıştır.","color":"gray"}]
