tellraw @s [{"text":"YAMAN CEPHE | ","color":"gold"},{"text":"[ARENAYA KATIL]","color":"aqua","clickEvent":{"action":"run_command","value":"/trigger cephe_katil"}},{"text":" Katılınca arena ekipmanına geçersin. Çıkış: /trigger cephe_cik","color":"gray"}]
tag @s add ym_bilgi
