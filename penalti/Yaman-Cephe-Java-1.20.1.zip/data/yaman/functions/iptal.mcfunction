scoreboard players set #aktif ym 0
scoreboard players set #bekle ym 15
tellraw @a[tag=ym_oyuncu] {"text":"Bir takımda oyuncu kalmadı. Yeni eşleşme bekleniyor.","color":"yellow"}
