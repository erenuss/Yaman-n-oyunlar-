scoreboard players set #aktif ym 0
scoreboard players set #bekle ym 30
execute if score Mavi Cephe > Altin Cephe run title @a[tag=ym_oyuncu] title {"text":"MAVİ BİRLİK KAZANDI","color":"aqua"}
execute if score Altin Cephe > Mavi Cephe run title @a[tag=ym_oyuncu] title {"text":"ALTIN BİRLİK KAZANDI","color":"gold"}
execute if score Altin Cephe = Mavi Cephe run title @a[tag=ym_oyuncu] title {"text":"BERABERE","color":"yellow"}
tellraw @a[tag=ym_oyuncu] {"text":"Tur bitti. Sonraki tur 30 saniye sonra başlayacak.","color":"green"}
