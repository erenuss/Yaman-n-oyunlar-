execute as @a[tag=!ym_bilgi] run function yaman:bilgi
scoreboard players enable @a cephe_katil
scoreboard players enable @a[tag=ym_oyuncu] cephe_cik
execute as @a[scores={cephe_katil=1..},tag=!ym_oyuncu] if score #hazir ym matches 1 run function yaman:katil
scoreboard players set @a[scores={cephe_katil=1..}] cephe_katil 0
execute as @a[tag=ym_oyuncu,scores={cephe_cik=1..}] run function yaman:cik
execute as @a[tag=ym_oyuncu,scores={ym_olum=1..},nbt=!{Health:0.0f}] run function yaman:yeniden_dog
scoreboard players add #tick ym 1
execute if score #tick ym matches 20.. if score #hazir ym matches 1 in yaman:cephe run function yaman:saniye
execute if score #tick ym matches 20.. run scoreboard players set #tick ym 0
