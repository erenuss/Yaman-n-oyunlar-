scoreboard players set @s cephe_cik 0
tag @s remove ym_oyuncu
team leave @s
clear @s minecraft:bow{YamanKit:1b}
clear @s minecraft:arrow{YamanKit:1b}
clear @s minecraft:bread{YamanKit:1b}
clear @s minecraft:leather_chestplate{YamanKit:1b}
clear @s minecraft:chainmail_helmet{YamanKit:1b}
clear @s minecraft:leather_leggings{YamanKit:1b}
clear @s minecraft:leather_boots{YamanKit:1b}
execute in minecraft:overworld run tp @s 0 100 0
execute in minecraft:overworld run spawnpoint @s 0 100 0
gamemode spectator @s
tellraw @s {"text":"Arenadan ayrıldın. Tekrar katıl: /trigger cephe_katil","color":"yellow"}
