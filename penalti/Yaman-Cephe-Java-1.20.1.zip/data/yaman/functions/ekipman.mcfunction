clear @s minecraft:bow{YamanKit:1b}
clear @s minecraft:arrow{YamanKit:1b}
clear @s minecraft:bread{YamanKit:1b}
give @s minecraft:bow{YamanKit:1b,Unbreakable:1b,display:{Name:'{"text":"Cephe Yayı","italic":false}'},Enchantments:[{id:"minecraft:infinity",lvl:1s}]} 1
give @s minecraft:arrow{YamanKit:1b} 1
give @s minecraft:bread{YamanKit:1b} 16
execute if entity @s[team=ym_mavi] run item replace entity @s armor.chest with minecraft:leather_chestplate{YamanKit:1b,Unbreakable:1b,display:{color:3847130}}
execute if entity @s[team=ym_altin] run item replace entity @s armor.chest with minecraft:leather_chestplate{YamanKit:1b,Unbreakable:1b,display:{color:16766720}}
item replace entity @s armor.head with minecraft:chainmail_helmet{YamanKit:1b,Unbreakable:1b}
item replace entity @s armor.legs with minecraft:leather_leggings{YamanKit:1b,Unbreakable:1b}
item replace entity @s armor.feet with minecraft:leather_boots{YamanKit:1b,Unbreakable:1b}
