execute if score #hazir ym matches 0 run function yaman:ilk_kurulum
execute if score #hazir ym matches 1 run tellraw @a {"text":"Cephe haritası hazır. Katılmak için /trigger cephe_katil","color":"green"}
